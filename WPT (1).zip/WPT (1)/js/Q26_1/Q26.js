function validate(){
    var name = document.getElementById("name").value;
    var dob = document.getElementById("b_date").value;
    var email = document.getElementById("mail").value;
    var lucky= document.getElementById("lucky").value;
    var gender = $("input[name=gender]:checked").val();
    var fav_food = [];
    $("input[name=fav]:checked").each(function() {
        fav_food.push($(this).val());
    });
    if(!(name.match(/^[a-zA-Z]+$/))){
        alert("Name should have only alphabets");
        return false;
    }
    if(lucky<1 || lucky>100){
        alert("Number should be between 1 and 100");
        return false;
    }
    if(!gender){
        alert("Please select gender");
        return false;
    }
    console.log(fav_food)
    if(fav_food.length==0){
        alert("Please select atleast one favourite food");
        return false;
    }
    const obj= {
        name:name,
        dob: dob,
        email:email,
        gender:gender,
        lucky:lucky,
        fav_food:fav_food,
    };
    localStorage.setItem("object",JSON.stringify(obj));
    return true;
}


function display(){
var retrievedObject = localStorage.getItem('object');
const dt = JSON.parse(retrievedObject);
var table = '<table><tr><th>Name</th><th>Birth Date</th><th>Email</th><th>Gender</th><th>Lucky number</th><th>Favorite food</th></tr><tr>'
for (var i in dt) {
    table += '<td>'+dt[i]+'</td>';
}
table += '</tr></table>';
document.getElementById("disp").innerHTML = table;
}
