function validate(){
    var id = document.getElementById("id").value;
    var name = document.getElementById("name").value;
    var b_date = document.getElementById("b_date").value;
    var s_date = document.getElementById("s_date").value;
    var total = document.getElementById("total").value;
    if(name.length<6)
        alert("Enter name with length greater than 5 chars");
    else if(b_date>s_date)
        alert("Shipping date should be greater than billing date");
    else{
        const obj= {
            id:id,
            name: name,
            b_date:b_date,
            s_date:s_date,
            total:total
        };
        localStorage.setItem("object",JSON.stringify(obj));
        window.open('./Order.html');
    }
}

function display1(){
    var retrievedObject = localStorage.getItem('object');
    const dt = JSON.parse(retrievedObject);
    var table = '<table><tr><th>Id</th><th>Name</th><th>Billing Date</th><th>Shipping Date</th><th>Total</th></tr><tr>'
    for (var i in dt) {
        table += '<td>'+dt[i]+'</td>';
    }
    table += '</tr></table>';
    document.getElementById("det").innerHTML = table;
}