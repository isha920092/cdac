function validate(){
    var name = document.getElementById("name").value;
    var e_code = document.getElementById("e_code").value;
    var doj = document.getElementById("doj").value;
    var addr= document.getElementById("addr").value;
    var dept = $("input[name=dept]:checked").val();
    var subj = [];
    $("input[name=subj]:checked").each(function() {
        subj.push($(this).val());
    });
    var training = $("#training option:selected").val();
    console.log(training)
    if(!(name.match(/^[a-zA-Z]+$/))){
        alert("Name should have only alphabets");
        return false;
    }
    if(!dept){
        alert("Please select department");
        return false;
    }
    // console.log(fav_food)
    if(subj.length==0){
        alert("Please select atleast one subject");
        return false;
    }
    const obj= {
        name:name,
        e_code: e_code,
        dept:  dept,
        doj:doj,
        addr:addr,
        subj:subj,
        training:training,
    };
    localStorage.setItem("obj",JSON.stringify(obj));
    return true;
}


function display(){
var retrievedObject = localStorage.getItem('obj');
const dt = JSON.parse(retrievedObject);
var table = '<table><tr><th>Name</th><th>Employee Code</th><th>Date of Joining</th><th>Department</th><th>Address</th><th>Subject</th><th>Training</th></tr><tr>'
for (var i in dt) {
    table += '<td>'+dt[i]+'</td>';
}
table += '</tr></table>';
document.getElementById("disp").innerHTML = table;
}
