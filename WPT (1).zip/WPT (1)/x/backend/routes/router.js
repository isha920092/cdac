const express=require("express")
const router=express.Router();

var data=[{id:1,name:'a'},{id:2,name:'b'},{id:3,name:'c'}]


router.get("/all/:id", (req, res) => {
    try {
        console.log(req.url)
        console.log("hi")
        const id = parseInt(req.params.id);
        let itemFound = false;

        for (const item of data) {
            console.log(item)
            if (item.id === id) {
                console.log(item)
                res.json(item);
                itemFound = true;
                break;
            }
        }

        if (!itemFound) {
            res.status(404).send("No data found");
        }
    } catch (error) {
        res.status(500).send("Server error");
    }
});
router.get('/all',(req,res)=>{
    try {
        console.log(req.url)
        console.log("bye")
        res.send(data)
    } catch (error) {
        res.status(404).send("no data found")
    }

})


router.post('/new',(req,res)=>{
    try {
        console.log("new")
        var {id,name}=req.body
        data.push({id,name})
        res.json({ message: "Data added successfully" });
    } catch (error) {
        res.status(404).send(err.message)
    }

})

router.delete("/del/:id",(req,res)=>{
    try {
        for(var i of data){
            if(i.id==id)
                data.splice(i,1);
        }
        res.json({ message: "Data added successfully" });
    } catch (error) {
        res.status(404).send("no data found")
    }

})

module.exports=router