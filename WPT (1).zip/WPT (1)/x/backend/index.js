const express= require("express");
const routes=require("./routes/router")
const cors=require("cors")
const bodyParser = require('body-parser');
const app=express();
app.use(bodyParser.json());
app.use(cors())
app.use("/",routes);


app.listen(3001,()=>console.log("listening at port 3001"))