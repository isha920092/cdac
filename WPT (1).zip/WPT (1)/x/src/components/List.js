import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Add from './Add';

function List() {
    const [user, setuser] = useState([])
    const [id, setid] = useState(0)
    const [n, setn] = useState('')
    useEffect(() => {
      axios.get('http://localhost:3001/all')
      .then((res)=>setuser(res.data))
      .catch((err)=>console.log(err))
    }, [])

    const click=(id)=>{
        console.log("c")
        axios.get(`http://localhost:3001/all/${id}`) 
       .then((res)=>console.log(res))
       .catch((err)=>console.log(err))
    }
    
    return ( 
        <div>
            list
{user.map(u=>(<button type='button' key={u.id} onClick={()=>click(u.id)}>{u.name}</button>))}
<Add user={user} u={setuser}/>
        </div>
     );
}

export default List;