import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Add(props) {
    const [id, setid] = useState(0)
    const [n, setn] = useState('')

    const click=()=>{
        console.log("c")
        axios.post('http://localhost:3001/new', {id:parseInt(id), name:n})
       .then((res)=>props.u(prev=>[...prev,{id:parseInt(id), name:n}]))
       .catch((err)=>console.log(err))
    }
    
    return ( 
        <div>
<input type="text" value={id} onChange={(event)=>setid(event.target.value)}></input>
<input type="text" value={n} onChange={(event)=>setn(event.target.value)}></input>
<button type='button' onClick={click}>add</button>
        </div>
     );
}

export default Add;