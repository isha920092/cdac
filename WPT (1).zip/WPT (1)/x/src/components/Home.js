
import React, { useState, useEffect } from 'react';
import axios from 'axios';
function Home() {
    const [search, setsearch] = useState("");
    
    const handleSearchChange = (event) => {
        setSearch(event.target.value);
    }

    useEffect(() => {
     fetch()
    }, [search])
    

    return ( 
        <div>
           <label for="search">search</label>
           <input type="text" id="search" name="search" value={search} onchange={handleSearchChange}></input>
          {search.map((s)=>(<Index p={s}/>))}
        </div>
     );
}

export default Home;