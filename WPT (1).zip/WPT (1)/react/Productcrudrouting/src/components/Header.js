const Header=()=>{
    var ob={backgroundColor:"blue",color:"white",paddingLeft:"200px"};
   return (
    <h1 style={ob}>Product Management system</h1>
   )
}
export default Header;