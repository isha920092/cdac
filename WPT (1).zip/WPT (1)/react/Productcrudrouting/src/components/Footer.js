import React from 'react'
import "./Footer.css";
const Footer=()=> {
  return (
    <div>
        <h4 className="footer">&copy; Copy rights reserved</h4>
    </div>
  )
}
export default  Footer;