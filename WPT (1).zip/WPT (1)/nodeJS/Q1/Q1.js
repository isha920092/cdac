const mod=require('./module');
const http=require('http');
const fs=require('fs')
const url=require('url')

var server=http.createServer(function(req,resp){
    var q=url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    switch(q.pathname){
        case "/form":
            var rs=fs.createReadStream("./Q1.html");
            rs.pipe(resp);
            break;

        case '/submit':
            resp.write("<h3>num1 : "+q.query.n1+"</h3>");
            resp.write("<h3>num2 : "+q.query.n2+"</h3>");
            var ans = 0;
            switch(q.query.op) {
                case 'add':
                    ans = mod.add(parseInt(q.query.n1),parseInt(q.query.n2));
                    resp.end("<h3>Addition : "+ans+"</h3>");
                    break;
                case 'sub':
                    ans = mod.sub(parseInt(q.query.n1),parseInt(q.query.n2));
                    resp.end("<h3>Subtraction : "+ans+"</h3>");
                    break;
                case 'mult':
                    ans = mod.multiply(parseInt(q.query.n1),parseInt(q.query.n2));
                    resp.end("<h3>Multiplication : "+ans+"</h3>");
                    break;
                case 'div':
                    ans = mod.divide(parseInt(q.query.n1),parseInt(q.query.n2));
                    resp.end("<h3>Division : "+ans+"</h3>");
                    break;
                case 'square':
                    ans = mod.square(parseInt(q.query.n1));
                    resp.end("<h3>Square : "+ans+"</h3>");
                    break;
                case 'sum':
                    ans = mod.sum(q.query.n1);
                    resp.end("<h3>Sum : "+ans+"</h3>");
                    break;
            }
            break;
        default:
            resp.write("<h1>In default case</h1>");
            resp.end();

    }


})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
