function add(a,b){
    return a+b;
}

function sub(a,b){
    return a-b;
}

function multiply(a,b){
    return a*b;
}

function divide(a,b){
    return a/b;
}

function square(a){
    return a*a;
}
function sum(...c){
    var tot=0;
    for(var i of c[0])
        if(!isNaN(parseInt(i)))
            tot+=parseInt(i);
    return tot;
}

module.exports={
    add:add,
    sub:sub,
    multiply:multiply,
    divide:divide,
    square:square,
    sum:sum
}