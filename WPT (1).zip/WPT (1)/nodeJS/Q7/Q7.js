const http=require('http');
const url=require('url');
const fs=require('fs');

var server=http.createServer(function(req,resp){
    var q=url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    switch(q.pathname){
        case '/':
            fs.readFile("mydata.txt",function(err,data){
                if(err)
                    console.log(err);
                else{
                    const lines = String(data).split(/\n+/);
                    var count = 1
                    for(var i of lines) {
                        resp.write(count + ". " + i + "<br/>");
                        count++;
                    }
                }    
            })
            break;
        default:
            resp.write("<h1>In default case</h1>");
            resp.end();
    }
})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
