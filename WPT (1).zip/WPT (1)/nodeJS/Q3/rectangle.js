function calcArea(length, breadth) {
    return parseInt(length) * parseInt(breadth);
}

function calcPerimeter(length, breadth) {
    return 2 * (parseInt(length) + parseInt(breadth));
}

module.exports = {
    calcArea: calcArea,
    calcPerimeter: calcPerimeter
}