function calcArea(radius) {
    return Math.PI*Math.pow(parseInt(radius), 2);
}

function calcCircumference(radius) {
    return 2*Math.PI*parseInt(radius);
}

function calcDiameter(radius) {
    return 2*parseInt(radius);
}

module.exports = {
    calcArea: calcArea,
    calcCircumference: calcCircumference,
    calcDiameter: calcDiameter
}