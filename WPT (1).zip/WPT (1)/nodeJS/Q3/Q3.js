const circle = require('./circle');
const rectangle = require('./rectangle');
const triangle = require('./triangle');
const http=require('http');
const fs=require('fs')
const url=require('url')

var server = http.createServer(function(req,resp) {
    var q = url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    switch(q.pathname){
        case "/form":
            var rs=fs.createReadStream("./Q3.html");
            rs.pipe(resp);
            break;
        case '/submit':
            switch(q.query.shape) {
                case 'circle' :
                    var radius = q.query.radius;
                    resp.write("<div>Area : "+circle.calcArea(radius)+"</div>");
                    resp.write("<div>Circumference : "+circle.calcCircumference(radius)+"</div>");
                    resp.write("<div>Circumference : "+circle.calcDiameter(radius)+"</div>")
                    break;
                case'rectangle' :
                    var length = q.query.len;
                    var breadth = q.query.breadth;
                    resp.write("<div>Area : "+rectangle.calcArea(length, breadth)+"</div>");
                    resp.write("<div>Perimeter : "+rectangle.calcPerimeter(length, breadth)+"</div>");
                    break;
                case'triangle' :
                    var side1 = q.query.side1;
                    var side2 = q.query.side2;
                    var side3 = q.query.side3;
                    resp.write("<div>Is triangle equilateral ? "+triangle.isEquilateral(side1, side2, side3)+"</div>");
                    resp.write("<div>Perimeter : "+triangle.calcPerimeter(side1, side2, side3)+"</div>");
                    break;
            }
            break;
        default:
            resp.write("<h1>In default case</h1>");
            resp.end();
    }
})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
