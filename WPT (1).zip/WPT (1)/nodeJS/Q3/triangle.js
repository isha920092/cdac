function isEquilateral(side1, side2, side3) {
    if (side1 == side2 && side2 == side3) {
        return "yes";
    }
    return "no";
}

function calcPerimeter(side1, side2, side3) {
    return parseInt(side1) + parseInt(side2) + parseInt(side3);
}

module.exports = {
    isEquilateral: isEquilateral,
    calcPerimeter: calcPerimeter
}