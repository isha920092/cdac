const http = require("http")
const fs = require("fs")
const url = require("url")
const mod = require("./validateUser")

var server=http.createServer(function(req,resp){
    var q = url.parse(req.url,true)
    resp.writeHeader(200,{"content-type":"text/html"})
    switch(q.pathname){
        case '/login': 
            var rs= fs.createReadStream("./Q9.html")
            rs.pipe(resp);
            break;
        case "/submit":
            var username = q.query.username
            var password = q.query.pass_word
            var pass_len = password.length
            if(pass_len >= 6) {
                var sss= fs.createReadStream("./success.html")
                var fal = fs.createReadStream("./failure.html")
                var answer= mod.validate_user(username,password)
                if(answer!==null){
                    sss.pipe(resp);
                    sss.on('end',()=> resp.end())
                }else{
                    fal.pipe(resp);
                    fal.on('end',()=> resp.end())
                }
            }
            else {
                resp.write("<h3>Password should be atleast 6 characters long!</h3>");
                resp.end();
            }
            break;
        default: 
            resp.write("Default case...")
            break;
    }
})

server.listen(3001,function(){
    console.log("Server is running at port 3001")
})