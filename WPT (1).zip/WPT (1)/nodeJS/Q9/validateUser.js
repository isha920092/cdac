var arr=[{username:'user1',passwd:'pass123'},{username:'user2',passwd:'pass222'}]
function validate_user(username,password){
    for(var ob of arr){
        if(ob.username===username && ob.passwd===password){
            return ob;
        }
    }
    return null
}

module.exports = {
    validate_user:validate_user
}