const http=require('http');

var server=http.createServer(function(req,resp){
    resp.writeHeader(200,{'content-type':'text/html'})
    resp.write("Welcome to nodeJS");
    resp.end();
})
server.listen(5000,function(){
    console.log("server is running on port 5000");
})
