const circle = require('../Q3/circle.js');
const http=require('http');
const fs=require('fs')
const url=require('url')

var server = http.createServer(function(req,resp) {
    var q = url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    var rs=fs.createReadStream("./Q8.html");
    switch(q.pathname){
        case "/":
            rs.pipe(resp);
            break;

        case '/submit':
            rs.pipe(resp);
            var radius = q.query.rad;
            rs.on('data',function()
            {
                resp.write("<div>Area : "+circle.calcArea(radius)+"</div>");
                resp.write("<div>Circumference : "+circle.calcCircumference(radius)+"</div>");
            })
            break;
        }
})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
