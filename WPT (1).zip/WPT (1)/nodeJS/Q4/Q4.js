const http=require('http');
const url=require('url')

var server=http.createServer(function(req,resp){
    var q=url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    switch(q.pathname){
        case '/':
            for(var n=1;n<=100;n++)
                if(n%3==0 && n%5==0)
                    resp.write("<div>fizzbuzz</div>");
                else if (n%3==0)
                        resp.write("<div>fizz</div>");
                else if (n%5==0)
                    resp.write("<div>buzz</div>");
                else
                    resp.write("<div>"+n+"</div>");
            break;
        default:
            resp.write("<h1>In default case</h1>");
            resp.end();
    }
})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
