const parser = require("body-parser");
const mod=require('./prime')
const express = require('express');
var app = express();

app.get('/', function (req, res) {
  res.sendFile("./Q10.html",{root:__dirname});
})

app.get('/submit', function (req, res) {
   if(mod.prime(req.query.num))
    res.send("Number is prime");
   else
    res.send("Number is not prime");
  })

app.listen(3000, function () {
  console.log('Server is running at port 3000')
})