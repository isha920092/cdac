const http=require('http');
const url=require('url');
const fs=require('fs');

var server=http.createServer(function(req,resp){
    var q=url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    switch(q.pathname){
        case '/':
            fs.readFile("mydata.txt",function(err,data){
                if(err)
                    console.log(err);
                else{
                    const words = String(data).split(/\s+/);
                    resp.write("mydata.txt file has " +words.length +" words<br/>");
                }    
            })

            fs.readFile("myfile.data",function(err,data){
                if(err)
                    console.log(err);
                else{
                    const words = String(data).split(/\s+/);
                    resp.write("myfile.data has " +words.length +" words");
                    resp.end();
                }    
            })
            break;
        default:
            resp.write("<h1>In default case</h1>");
            resp.end();
    }
})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
