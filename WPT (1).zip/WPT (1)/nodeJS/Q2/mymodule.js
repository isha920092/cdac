function factorial(a){
    let fact = 1;
    for(a; a>0; a--)
        fact *= a;
    return fact;
}

function myprime(a){
    for(var i=2;i<a;i++)
        if(a%i==0)
            return false;
    return true;
}

function printable(a){
    var table='<div>'
    for(var i=1; i<=10; i++){
        table += `${a} * ${i} = ${a*i} <br/>`;
    }
    table += '</div>';
    return table;
}

module.exports={
    factorial:factorial,
    myprime:myprime,
    printable:printable
}