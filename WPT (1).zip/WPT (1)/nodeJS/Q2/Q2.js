const mod=require('./mymodule');
const http=require('http');
const fs=require('fs');
const url=require('url')

var server=http.createServer(function(req,resp){
    var q=url.parse(req.url,true)
    resp.writeHeader(200,{'content-type':'text/html'})
    switch(q.pathname){
        case "/form":
            var rs=fs.createReadStream("./Q2.html");
            rs.pipe(resp);
            break;

        case '/submit':
            var n = q.query.n;
            resp.write("<div>Number : "+n+"</div>");
            if (n>0 && n<5)
                resp.write("<div>Factorial : "+mod.factorial(n)+"</div>");
            else if (n>=5 && n<10)
                resp.write(mod.printable(n));
            else
                resp.write("<div>Is prime : "+mod.myprime(n)+"</div>");
            break;
        default:
            resp.write("<h1>In default case</h1>");
            resp.end();
    }
})
server.listen(3001,function(){
    console.log("server is running on port 3001");
})
